﻿# Strike Force

Tactical 5-vs-5 shooter (bomb-defusal mode) featuring bots – offline, for Windows 10/11.

## Getting Started

Double-click `StrikeForce.exe`. No installation required (.NET Framework 4 is included with Windows).

## Technical Details

- Language: **C# 5**; UI and 3D rendering: **WPF** (built into Windows). *Not* built on Unreal Engine.
- Audio: Custom audio mixer utilizing `winmm.dll` (supports spatial sound and sound attenuation behind walls). All sound effects and music are generated at runtime (no external files).
- Textures: Generated procedurally at startup (no image files required).

## New Map: "Mirage" (October 25, 2026)

The previous map, "Oase" (Oasis), has been completely replaced (backups available at `backup\StrikeForce_vor_Map-Neubau_2026-10-25.zip` and `backup\Oase-Map\Welt_Oase.cs`). This is an original design modeled after a Mediterranean desert town; it contains no assets from CS2.

- **Technical Implementation** (`Welt.cs`): Uses a 120 × 120 grid with **1-meter** cells (previously 50 × 50 with 2-meter cells). Each cell includes a floor, with optional ceilings and roofs—enabling fully realized interior spaces, underpasses, window openings with parapets, staircases (with 0.4-meter risers), and inclined ramps. Adjacent floor, wall, and roof surfaces with identical shading are merged into larger planes; textures are generated in parallel. - **Layout** (`Karte.cs`): T Spawn, T Ramp, Tetris, A Ramp, A Site, Palace (alleyway, hall with columns, balcony), Top Mid, Mid, Catwalk, Short, Underpass (-3.2 m), B Entrance, B Apps (upper floor with apartments), T Apps, B Site, Back Site (colonnade), Market (door + window facing B), CT Spawn, CT paths to A (Ticket Booth) and B, Connector, Jungle (arcade), Window (room with an actual opening toward Mid, stairwell).
- **Objects and Facades** (`Requisiten.cs`): Crates with trim, stone walls, columns, rounded arches, palm trees, pots, barrels, sandbags, delivery vans, ticket booths, market stalls, shelves, fountains, furniture; windows with shutters/grilles/balconies, arched wooden doors, awnings, cornices with parapets, floor-level bands, lamps, downpipes, air conditioning units, clotheslines, power lines. New textures: aged plaster with chipped areas, stone blocks, irregular floor slabs, awning fabric, painted shutters.
- **Bomb Sites** defined via area markers (`Zelle.Site`); the HUD displays "BOMB SITE A/B," and the radar is generated from the actual grid layout.
- **Camera** glides smoothly over steps and ramps.
- **Tests**: `--maptest=FOLDER` (top-down view, aerial view, 20 perspective snapshots, pathfinding from both spawns to all locations—verifying movement using actual player physics—plus spawn and zone validation) and `--bombentest` (includes only the bomb carrier and one CT; bots are set to ignore each other—verifies planting and defusing mechanics). - **Measurement** (3 runs each, same session, 5v5 spectator view): old avg. 42.2 FPS / 4.8 s startup / 213 MB; new avg. 39 FPS / 4.0 s / 268 MB (156,000 triangles).

## Quality Upgrade (Oct 25, 2026)

- **Characters** (`Kaempfer.cs`): smooth shapes (`MeshBau.Rund` = superellipsoid, `MeshBau.Rohr` = limb segment with two radii); hip/knee joints with animations for running, crouching, jumping, firing (recoil), reloading, and weapon switching. Shapes are generated once per team and shared as frozen (static) meshes.
- **Weapons** (`Waffen.cs`): rounded housings/handguards, Picatinny rails, ventilation slots, ejection ports, wooden and telescopic stocks, wood grain textures; first-person hands featuring fingers and rounded forearms.
- **Map Textures** (`Hilfe.cs`): tiles without a checkerboard pattern; sandstone/paving with baked-in edge shading (`Tex.Fase`); Cordura, camouflage fabric, and skin textures for characters.
- **HUD** (`Hud.cs`): player chips with health bars, 4× radar with outlines, weapon icons in the kill feed, "Eliminated by…," and scaling based on window height.
- **Map Selection** (`Menue.cs`): large previews, a transparent list of planned maps, and an indicator showing the current selection. - **Measurement** (identical conditions, 3 runs each, 5v5, effects "On"): before – avg. 29.2 FPS / 4.5 s startup / 157 MB; after – avg. 31.6 FPS / 4.8 s / 185 MB.
- Backup of the previous version: `backup\StrikeForce_vor_Qualitaets-Upgrade_2026-10-25.zip`.
- Test flags: `--posen=file.png` (character poses), `--waffen=file.png` (weapon sheet).

## Logo

`bilder/logo.png` (menu) and `bilder/logo_sf.png` (window icon) were cropped from `bilder/logo_original.png` (with the dark background made transparent) and embedded into the executable.

## Graphics

- Color grading (contrast, saturation, cool shadows/warm highlights) is baked into all textures (`Tex.Look`); this incurs no FPS cost.
- Soft shadow edges: 4 sampling points per 0.5m floor tile (penumbra), with contact shadows at the base of walls.
- Effects: Off / On (vignette) / Cinematic (includes an additional pixel shader, `shader/Farbkorrektur.fx`, costing approx. 6 FPS).
- Testing: `--fps` measures performance over 15 seconds during a match → `%TEMP%\strikeforce_fps.txt`; `--effekte=0|1|2`.
- Recompiling shaders: `fxc /T ps_2_0 /E main /Fo shader\Farbkorrektur.ps shader\Farbkorrektur.fx` (save the file without a BOM). ## Build yourself

In the `StrikeForce` folder in PowerShell:

```powershell
$fw = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319"
& "$fw\csc.exe" /target:winexe /codepage:65001 /optimize /out:StrikeForce.exe /lib:"$fw\WPF" /r:PresentationFramework.